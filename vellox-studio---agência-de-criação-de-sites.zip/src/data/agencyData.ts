export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  deliveryTime: string;
  features: string[];
  idealFor: string;
  highlight?: string;
  whatsappMessage: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  client: string;
  category: 'professional' | 'menu' | 'institutional' | 'redesign';
  categoryLabel: string;
  description: string;
  image: string;
  results: string;
  tags: string[];
  deliverable: string;
  deliverySpeed: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  quote: string;
  rating: number;
  highlightMetric: string;
}

export const AGENCY_INFO = {
  name: 'Vellox Studio',
  tagline: 'Seu negócio merece estar no próximo nível',
  phoneDisplay: '(11) 91022-2221',
  phoneRaw: '551191022221',
  instagramHandle: '@velloxstudio.ofc',
  instagramUrl: 'https://instagram.com/velloxstudio.ofc',
  whatsappBaseUrl: 'https://wa.me/551191022221',
  location: 'São Paulo, SP · Atendimento para todo o Brasil',
  defaultWhatsappText: 'Olá Vellox Studio! Gostaria de solicitar um orçamento para o meu site.',
};

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: 'sites-profissionais',
    title: 'Criação de Sites Profissionais',
    subtitle: 'Presença digital marcante com alta taxa de conversão',
    description: 'Desenvolvimento de sites estratégicos de alta performance projetados especificamente para posicionar sua empresa à frente da concorrência e transformar visitantes em clientes.',
    deliveryTime: 'Entrega ágil em até 1h',
    features: [
      'Design exclusivo de alto padrão visual',
      'Layout 100% responsivo para celulares e computadores',
      'Integração direta com WhatsApp e chamadas de ação',
      'Otimização básica de SEO para aparecer no Google',
      'Carregamento ultra-rápido em menos de 1 segundo',
    ],
    idealFor: 'Empresas, prestadores de serviços, escritórios e autônomos que buscam autoridade.',
    highlight: 'Mais Solicitado',
    whatsappMessage: 'Olá! Tenho interesse no serviço de Criação de Sites Profissionais da Vellox Studio. Podemos conversar sobre um orçamento?',
  },
  {
    id: 'cardapios-digitais',
    title: 'Cardápios Digitais',
    subtitle: 'Experiência gastronômica moderna e sem intermediários',
    description: 'Solução sob medida para restaurantes, bares, lanchonetes e cafeterias que desejam encantar o cliente na mesa ou no delivery, sem pagar comissões abusivas por pedido.',
    deliveryTime: 'Entrega em até 1h',
    features: [
      'Navegação intuitiva por fotos e categorias',
      'Atualização instantânea de pratos e preços',
      'Acesso rápido via QR Code sem necessidade de baixar app',
      'Botão de pedido direto para o WhatsApp do restaurante',
      'Visual moderno que valoriza os pratos e aumenta o tíquete médio',
    ],
    idealFor: 'Restaurantes, hamburguerias, bistrôs, pizzarias e confeitarias.',
    whatsappMessage: 'Olá! Gostaria de um orçamento para a criação de um Cardápio Digital para o meu estabelecimento.',
  },
  {
    id: 'sites-institucionais',
    title: 'Sites Institucionais',
    subtitle: 'Credibilidade corporativa e solidez para marcas exigentes',
    description: 'Estrutura completa e elegante para empresas consolidadas ou em expansão. Apresentação impecável de história, equipe, áreas de atuação, cases de sucesso e canais de contato.',
    deliveryTime: 'Entrega expressa personalizada',
    features: [
      'Arquitetura de informação corporativa e refinada',
      'Páginas completas: Quem Somos, Serviços, Cases e Contato',
      'Conformidade com LGPD e políticas de privacidade',
      'Formulários com validação e segurança integrada',
      'Identidade alinhada ao posicionamento de luxo da sua marca',
    ],
    idealFor: 'Indústrias, construtoras, escritórios jurídicos, consultorias e empresas B2B.',
    whatsappMessage: 'Olá! Preciso de um Site Institucional de alto padrão para minha empresa. Podemos agendar uma conversa?',
  },
  {
    id: 'redesign-de-sites',
    title: 'Redesign de Sites',
    subtitle: 'Modernização visual e técnica para sites que pararam no tempo',
    description: 'Se o seu site atual é antigo, lento, desconfigurado no celular ou simplesmente não traz vendas, nós recriamos do zero uma experiência contemporânea focada em resultados.',
    deliveryTime: 'Entrega ágil em até 1h',
    features: [
      'Auditoria completa dos pontos fracos do site atual',
      'Nova estética moderna alinhada às tendências mundiais',
      'Melhoria drástica na velocidade de carregamento',
      'Reestruturação dos fluxos de contato e conversão',
      'Migração segura sem perda de conteúdo relevante',
    ],
    idealFor: 'Empresas que já possuem site mas não obtêm retorno ou sentem vergonha do visual atual.',
    highlight: 'Retorno Imediato',
    whatsappMessage: 'Olá! Meu site atual está desatualizado e preciso de um Redesign profissional com a Vellox Studio.',
  },
];

export const PORTFOLIO_LIST: PortfolioItem[] = [
  {
    id: 'arcus-partners',
    title: 'Arcus Partners & Engenharia',
    client: 'Arcus Engenharia & Construção',
    category: 'professional',
    categoryLabel: 'Site Profissional',
    description: 'Site corporativo de alto padrão para escritório de engenharia e projetos arquitetônicos, com foco na captação de clientes de médio e grande porte.',
    image: '/src/assets/images/portfolio_corporate_site_1794337248979.jpg',
    results: '+220% em contatos qualificados no primeiro mês',
    tags: ['Design Corporativo', 'Mobile First', 'Ultra Rápido'],
    deliverable: 'Site Profissional Completo',
    deliverySpeed: 'Entregue em 1h com aprovação imediata',
  },
  {
    id: 'noctua-dining',
    title: 'Noctua Fine Dining',
    client: 'Noctua Gastronomia',
    category: 'menu',
    categoryLabel: 'Cardápio Digital',
    description: 'Experiência gastronômica interativa com fotos em alta resolução, seções por pratos do chef e QR Code de mesa para atendimento rápido.',
    image: '/src/assets/images/portfolio_menu_digital_1794337249057.jpg',
    results: 'Redução de 35% no tempo de atendimento nas mesas',
    tags: ['Cardápio Interativo', 'QR Code', 'Sem Taxas'],
    deliverable: 'Cardápio Digital Mobile & QR Code',
    deliverySpeed: 'Configurado e no ar em 45 minutos',
  },
  {
    id: 'elara-advisory',
    title: 'Elara Strategic Advisory',
    client: 'Elara Consultoria Corporativa',
    category: 'institutional',
    categoryLabel: 'Site Institucional',
    description: 'Presença digital imponente para consultoria de fusões, aquisições e governança para executivos e fundos de investimento.',
    image: '/src/assets/images/portfolio_institutional_1794337247117.jpg',
    results: 'Validação de autoridade para contratos de 7 dígitos',
    tags: ['Design Executivo', 'Tipografia Nobre', 'LGPD'],
    deliverable: 'Portal Institucional Multi-páginas',
    deliverySpeed: 'Entregue em prazo recorde com refinamento total',
  },
  {
    id: 'aurelia-clinica',
    title: 'Clínica Aurélia Estética',
    client: 'Aurélia Dermatologia & Estética',
    category: 'redesign',
    categoryLabel: 'Redesign de Site',
    description: 'Transformação de um site obsoleto em uma vitrine digital sofisticada e acolhedora, facilitando o agendamento direto de procedimentos pelo WhatsApp.',
    image: '/src/assets/images/portfolio_redesign_clinic_1794337248671.jpg',
    results: 'Aumento de 180% no agendamento de consultas particulares',
    tags: ['Redesign Completo', 'Agendamento WhatsApp', 'Alta Conversão'],
    deliverable: 'Redesign Visual & Otimização Mobile',
    deliverySpeed: 'Migração concluída em menos de 1h',
  },
];

export const TESTIMONIALS_LIST: TestimonialItem[] = [
  {
    id: 'dep-1',
    name: 'Dr. Marcelo Vasconcelos',
    role: 'Diretor Clínico',
    company: 'Instituto Vasconcelos de Medicina',
    quote: 'O site que a Vellox Studio desenvolveu mudou completamente o patamar da nossa clínica. Nossos pacientes elogiam a facilidade no celular e o tíquete médio das consultas aumentou consideravelmente.',
    rating: 5,
    highlightMetric: '+180% em agendamentos diretos',
  },
  {
    id: 'dep-2',
    name: 'Sofia Andrade',
    role: 'Sócia-Proprietária',
    company: 'Noctua Bistrô & Gastronomia',
    quote: 'Estávamos cansados de pagar mensalidades caras e porcentagens em plataformas de pedidos. A Vellox entregou nosso cardápio digital em tempo recorde e o resultado visual ficou impecável.',
    rating: 5,
    highlightMetric: 'Economia de R$ 3.800/mês em taxas',
  },
  {
    id: 'dep-3',
    name: 'Carlos Henrique Mendes',
    role: 'Engenheiro Sócio',
    company: 'Arcus Engenharia & Obras',
    quote: 'Prometeram entrega em até 1h e cumpriram com uma qualidade profissional de agências que cobram 10 vezes mais. Sem enrolação, sem preços absurdos e com suporte direto excelente.',
    rating: 5,
    highlightMetric: 'Entrega recorde em 50 minutos',
  },
  {
    id: 'dep-4',
    name: 'Amanda Ribeiro',
    role: 'Head de Negócios',
    company: 'Elara Strategic Advisors',
    quote: 'Para fechar contratos corporativos de alto valor, nosso site precisava transmitir seriedade imediata. A Vellox Studio entendeu nossa necessidade perfeitamente. Recomendo de olhos fechados.',
    rating: 5,
    highlightMetric: '100% de satisfação com o design',
  },
];

export const STATS = [
  { value: '+100', label: 'Sites Entregues', sublabel: 'Para empresas de todo o Brasil' },
  { value: 'Até 1h', label: 'Prazo de Entrega', sublabel: 'Agilidade sem perder a qualidade' },
  { value: '99.4%', label: 'Aprovação de Clientes', sublabel: 'Satisfação garantida ou ajuste imediato' },
  { value: '100%', label: 'Foco em Conversão', sublabel: 'Desenvolvido para gerar contatos' },
];

export const DIFFERENTIALS = [
  {
    title: 'Qualidade Profissional de Alto Padrão',
    description: 'Sites construídos com código limpo, design contemporâneo e tipografia refinada. Nada de layouts amadores ou soluções genéricas.',
    badge: 'Padrão Internacional',
  },
  {
    title: 'Sem Preços Absurdos',
    description: 'Investimento justo, transparente e acessível. Você não precisa gastar uma fortuna para ter um site digno das maiores marcas do mercado.',
    badge: 'Custo-Benefício Real',
  },
  {
    title: 'Entregamos em até 1h',
    description: 'Processo inteligente e metodologia acelerada para colocar seu negócio no ar hoje mesmo, sem meses de espera intermináveis.',
    badge: 'Velocidade Imbatível',
  },
];
