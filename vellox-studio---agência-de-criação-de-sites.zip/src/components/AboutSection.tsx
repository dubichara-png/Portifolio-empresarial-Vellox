import React from 'react';
import { Target, Award, Rocket, CheckCircle } from 'lucide-react';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-20 md:py-28 bg-[#0D0D0D] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#D4AF37] mb-3">
            <span>Sobre a Vellox Studio</span>
            <span aria-hidden="true">·</span>
            <span>Experiência & Resultados</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white leading-tight text-balance">
            Especialistas em criar presença digital que impulsiona o crescimento do seu negócio.
          </h2>
        </div>

        {/* 2-Column Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mt-12 items-start">
          
          {/* Main Story Narrative */}
          <div className="lg:col-span-7 space-y-6 text-neutral-300 leading-relaxed text-base sm:text-lg">
            <p className="font-normal">
              A <strong className="text-white font-semibold">Vellox Studio</strong> nasceu com uma missão clara: 
              proporcionar a pequenas, médias e grandes empresas o mesmo padrão visual, tecnológico e 
              estratégico que as líderes de mercado utilizam, sem burocracias lentas e sem orçamentos exorbitantes.
            </p>
            <p>
              Somos especialistas na criação de sites profissionais, modernos e estratégicos para empresas de 
              diversos segmentos. Já desenvolvemos mais de 100 sites, ajudando negócios a fortalecer sua presença 
              digital, conquistar clientes e crescer de forma sustentável na internet.
            </p>
            <p>
              Nosso foco são empresas que desejam se destacar da concorrência, transmitir credibilidade imediata 
              e conquistar mais oportunidades comerciais através de um site profissional.
            </p>

            {/* Checklist of guarantees */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="flex items-center gap-2.5 text-sm text-neutral-200">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Mais de 100 projetos entregues</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm text-neutral-200">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Atendimento humanizado e ágil</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm text-neutral-200">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Domínio e hospedagem simplificados</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm text-neutral-200">
                <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Entrega recorde em até 1 hora</span>
              </div>
            </div>

            <div className="pt-4">
              <a
                href={createWhatsAppUrl('Olá Vellox Studio! Li sobre a agência e gostaria de entender como vocês podem criar o site da minha empresa.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#D4AF37] hover:text-[#F3E5AB] transition-colors focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
              >
                <span>Converse diretamente com nosso time de especialistas</span>
                <span aria-hidden="true">&rarr;</span>
              </a>
            </div>
          </div>

          {/* Right Column: 3 Strategic Pillars Cards */}
          <div className="lg:col-span-5 space-y-4">
            
            <div className="p-6 rounded-xl bg-[#141414] border border-white/5 hover:border-[#D4AF37]/30 transition-all">
              <div className="flex items-center gap-3 mb-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
                  <Target className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white">Posicionamento & Autoridade</h3>
              </div>
              <p className="text-sm text-neutral-400 leading-relaxed">
                Um site mal feito afasta clientes de alto valor. Nós alinhamos cada detalhe visual e textual para que seu negócio transmita solidez e confiança instantânea ao primeiro clique.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#141414] border border-white/5 hover:border-[#D4AF37]/30 transition-all">
              <div className="flex items-center gap-3 mb-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
                  <Rocket className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white">Engenharia de Conversão</h3>
              </div>
              <p className="text-sm text-neutral-400 leading-relaxed">
                Não fazemos apenas sites bonitos. Estruturamos botões de chamada no WhatsApp estrategicamente posicionados, formulários de contato ágeis e arquitetura para converter visitas em vendas.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#141414] border border-[#D4AF37]/25 shadow-lg shadow-black/50 transition-all">
              <div className="flex items-center gap-3 mb-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                  <Award className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-[#F3E5AB]">Agilidade Real (Até 1h)</h3>
              </div>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Desenvolvemos um fluxo de trabalho direto, sem reuniões redundantes e sem enrolação. Seu negócio precisa vender agora, e nós garantimos sua entrega no mesmo dia.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
