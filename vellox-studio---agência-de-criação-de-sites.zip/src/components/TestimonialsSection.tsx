import React from 'react';
import { Star, Quote, ArrowRight } from 'lucide-react';
import { TESTIMONIALS_LIST } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="depoimentos" className="py-20 md:py-28 bg-[#0A0A0A] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#D4AF37] mb-2.5">
            <span>Depoimentos & Avaliações</span>
            <span aria-hidden="true">·</span>
            <span>Experiência Comprovada</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white leading-tight">
            O que dizem os empresários que confiaram seu posicionamento à Vellox Studio.
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 mt-3">
            Resultados mensuráveis, atendimento sem burocracia e entrega rápida que geram parcerias de longo prazo.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {TESTIMONIALS_LIST.map((item) => (
            <div
              key={item.id}
              className="p-7 sm:p-8 rounded-2xl bg-[#121212] border border-white/10 hover:border-[#D4AF37]/40 transition-all duration-300 flex flex-col justify-between relative group"
            >
              <div>
                {/* Header of review: stars + quote icon */}
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-1" aria-label="Avaliação 5 estrelas">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#D4AF37] text-[#D4AF37]" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-white/10 group-hover:text-[#D4AF37]/30 transition-colors" />
                </div>

                {/* Quote Text */}
                <p className="text-sm sm:text-base text-neutral-300 leading-relaxed mb-6 italic">
                  "{item.quote}"
                </p>
              </div>

              {/* Author footer + highlight metric */}
              <div className="pt-5 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#1C1C1C] border border-[#D4AF37]/40 flex items-center justify-center font-bold text-xs text-[#D4AF37]">
                    {item.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{item.name}</h4>
                    <p className="text-xs text-neutral-400">{item.role} · {item.company}</p>
                  </div>
                </div>

                {/* Highlight metric tag */}
                <div className="text-right sm:text-right">
                  <span className="text-[11px] font-semibold text-[#F3E5AB] bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-2.5 py-1 rounded-md inline-block">
                    {item.highlightMetric}
                  </span>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#141414] via-[#161616] to-[#121212] border border-[#D4AF37]/30 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-lg sm:text-xl font-bold text-white">
              Pronto para ser o próximo case de sucesso da sua categoria?
            </h4>
            <p className="text-xs sm:text-sm text-neutral-400">
              Solicite seu orçamento agora mesmo e receba o planejamento do seu site em minutos.
            </p>
          </div>

          <a
            href={createWhatsAppUrl('Olá Vellox Studio! Vi os depoimentos dos clientes e gostaria de dar o próximo passo para o site da minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-bold text-[#0A0A0A] bg-[#D4AF37] hover:bg-[#C59F2D] rounded-xl transition-all shadow-md shadow-[#D4AF37]/20 whitespace-nowrap shrink-0"
          >
            <span>Quero Meu Site Profissional</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
};
