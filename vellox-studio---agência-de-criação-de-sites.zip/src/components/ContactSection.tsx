import React, { useState } from 'react';
import { MessageSquare, Send, CheckCircle2, Phone, Instagram, Clock, MapPin, Sparkles } from 'lucide-react';
import { AGENCY_INFO, SERVICES_LIST } from '../data/agencyData';
import { createWhatsAppUrl, formatQuoteMessage } from '../utils/whatsapp';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    company: '',
    service: SERVICES_LIST[0].title,
    urgency: 'Entrega em até 1h (Urgente)',
    details: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      setError('Por favor, informe seu nome completo.');
      return;
    }
    if (!formData.phone.trim() || formData.phone.length < 8) {
      setError('Por favor, informe seu telefone com WhatsApp válido.');
      return;
    }

    // Build the formatted whatsapp message and open WhatsApp
    const whatsappMessage = formatQuoteMessage(formData);
    const whatsappUrl = createWhatsAppUrl(whatsappMessage);

    setSubmitted(true);
    
    // Open WhatsApp in a new tab for seamless user action
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-20 md:py-28 bg-[#0D0D0D] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#D4AF37] mb-2.5">
            <span>Solicitar Orçamento</span>
            <span aria-hidden="true">·</span>
            <span>Atendimento Imediato</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white leading-tight">
            Pronto para colocar sua marca no próximo nível?
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 mt-3">
            Preencha os dados abaixo para receber uma estimativa personalizada ou chame diretamente no WhatsApp oficial.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Info & Trust Badges */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="p-7 rounded-2xl bg-[#121212] border border-white/10 space-y-6">
              <h3 className="text-lg font-bold text-white">
                Canais de Atendimento Oficial
              </h3>
              
              <div className="space-y-4">
                {/* WhatsApp */}
                <a
                  href={createWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#181818] hover:bg-[#1E1E1E] border border-white/5 hover:border-[#D4AF37]/40 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0 group-hover:scale-105 transition-transform">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400">WhatsApp Comercial</div>
                    <div className="text-sm font-bold text-white group-hover:text-[#F3E5AB] transition-colors">
                      {AGENCY_INFO.phoneDisplay}
                    </div>
                    <div className="text-[11px] text-[#D4AF37] mt-0.5 font-medium">
                      Resposta média em menos de 5 minutos
                    </div>
                  </div>
                </a>

                {/* Instagram */}
                <a
                  href={AGENCY_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#181818] hover:bg-[#1E1E1E] border border-white/5 hover:border-[#D4AF37]/40 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] shrink-0 group-hover:scale-105 transition-transform">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400">Instagram Oficial</div>
                    <div className="text-sm font-bold text-white group-hover:text-[#F3E5AB] transition-colors">
                      {AGENCY_INFO.instagramHandle}
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-0.5">
                      Acompanhe bastidores e novos lançamentos
                    </div>
                  </div>
                </a>

                {/* Horário & Abrangência */}
                <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#181818] border border-white/5">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-neutral-300 shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400">Disponibilidade</div>
                    <div className="text-sm font-bold text-white">
                      Segunda a Sábado · 08h às 21h
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-0.5">
                      Plantão para entregas expressas de 1h
                    </div>
                  </div>
                </div>

                {/* Localização */}
                <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-[#181818] border border-white/5">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-neutral-300 shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400">Sede & Atendimento</div>
                    <div className="text-sm font-bold text-white">
                      {AGENCY_INFO.location}
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Quick Assurance Box */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-[#121212] to-[#0E0E0E] border border-[#D4AF37]/20 flex items-center gap-4">
              <Sparkles className="w-8 h-8 text-[#D4AF37] shrink-0" />
              <div className="text-xs text-neutral-300 leading-relaxed">
                <strong className="text-white block font-semibold mb-0.5">Compromisso Vellox:</strong>
                Orçamento transparente, sem letras miúdas e sem custos de manutenção compulsórios.
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="p-7 sm:p-9 rounded-2xl bg-[#121212] border border-white/10 shadow-2xl relative">
              
              {submitted ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] mx-auto flex items-center justify-center text-[#D4AF37]">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-white">
                    Solicitação Encaminhada!
                  </h3>
                  <p className="text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                    Sua mensagem foi formatada e aberta no WhatsApp com o time da <strong>Vellox Studio</strong>. 
                    Caso a janela não tenha aberto automaticamente, clique no botão abaixo.
                  </p>
                  <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                    <a
                      href={createWhatsAppUrl(formatQuoteMessage(formData))}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#D4AF37] text-[#0A0A0A] font-bold text-xs sm:text-sm hover:bg-[#C59F2D] transition-all"
                    >
                      <MessageSquare className="w-4 h-4 fill-current" />
                      <span>Abrir Conversa no WhatsApp</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs sm:text-sm font-medium border border-white/10 transition-colors"
                    >
                      Enviar Nova Mensagem
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="border-b border-white/5 pb-4 mb-2">
                    <h3 className="text-lg font-bold text-white">
                      Formulário de Orçamento Rápido
                    </h3>
                    <p className="text-xs text-neutral-400 mt-1">
                      Envie as informações do seu projeto. Retornamos com proposta sob medida.
                    </p>
                  </div>

                  {error && (
                    <div className="p-3 rounded-lg bg-red-950/60 border border-red-800 text-red-200 text-xs">
                      {error}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Nome */}
                    <div>
                      <label htmlFor="name" className="block text-xs font-semibold text-neutral-200 mb-1.5">
                        Seu Nome Completo *
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Ex: Roberto Silveira"
                        required
                        className="w-full px-4 py-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-colors"
                      />
                    </div>

                    {/* Telefone / WhatsApp */}
                    <div>
                      <label htmlFor="phone" className="block text-xs font-semibold text-neutral-200 mb-1.5">
                        WhatsApp com DDD *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="Ex: (11) 99999-8888"
                        required
                        className="w-full px-4 py-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Empresa */}
                    <div>
                      <label htmlFor="company" className="block text-xs font-semibold text-neutral-200 mb-1.5">
                        Nome da Sua Empresa ou Negócio
                      </label>
                      <input
                        type="text"
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        placeholder="Ex: Silveira Advocacia / Restaurante Sabor"
                        className="w-full px-4 py-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-colors"
                      />
                    </div>

                    {/* Serviço */}
                    <div>
                      <label htmlFor="service" className="block text-xs font-semibold text-neutral-200 mb-1.5">
                        Serviço Desejado *
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={formData.service}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-colors"
                      >
                        {SERVICES_LIST.map((srv) => (
                          <option key={srv.id} value={srv.title} className="bg-[#1A1A1A] text-white">
                            {srv.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Urgência / Prazo */}
                  <div>
                    <label htmlFor="urgency" className="block text-xs font-semibold text-neutral-200 mb-1.5">
                      Prazo Desejado
                    </label>
                    <select
                      id="urgency"
                      name="urgency"
                      value={formData.urgency}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-colors"
                    >
                      <option value="Entrega em até 1h (Urgente)">Entrega em até 1h (Urgente)</option>
                      <option value="Em até 24 horas">Em até 24 horas</option>
                      <option value="Dentro desta semana">Dentro desta semana</option>
                      <option value="Apenas pesquisando orçamento">Apenas pesquisando orçamento</option>
                    </select>
                  </div>

                  {/* Detalhes / Mensagem */}
                  <div>
                    <label htmlFor="details" className="block text-xs font-semibold text-neutral-200 mb-1.5">
                      Conte um pouco sobre seu projeto (opcional)
                    </label>
                    <textarea
                      id="details"
                      name="details"
                      rows={3}
                      value={formData.details}
                      onChange={handleInputChange}
                      placeholder="Ex: Já tenho logo e fotos dos produtos, preciso de um site moderno que funcione bem no celular para divulgar no Instagram..."
                      className="w-full px-4 py-3 rounded-xl bg-[#1A1A1A] border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] transition-colors resize-none"
                    />
                  </div>

                  {/* Submit CTA */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#C59F2D] text-[#0A0A0A] font-bold text-sm sm:text-base hover:opacity-95 active:scale-[0.99] transition-all flex items-center justify-center gap-2.5 shadow-lg shadow-[#D4AF37]/20 focus-visible:ring-2 focus-visible:ring-white outline-none"
                    >
                      <MessageSquare className="w-5 h-5 fill-current" />
                      <span>Solicitar Orçamento no WhatsApp Agora</span>
                    </button>
                    <p className="text-[11px] text-neutral-400 text-center mt-2.5">
                      Ao clicar, você será direcionado para o WhatsApp oficial com a mensagem pronta. Sem spam.
                    </p>
                  </div>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
