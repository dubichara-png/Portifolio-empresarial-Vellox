import React from 'react';
import { Instagram, MessageSquare, ArrowUp, ShieldCheck } from 'lucide-react';
import { AGENCY_INFO, SERVICES_LIST } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#080808] border-t border-white/10 text-neutral-400 text-xs pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/5">
          
          {/* Brand Column (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5 text-xl font-bold tracking-tight text-white">
              <div className="w-7 h-7 rounded-lg bg-[#141414] border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37] font-bold text-sm">
                V
              </div>
              <span>
                Vellox<span className="text-[#D4AF37]">.</span>Studio
              </span>
            </div>
            
            <p className="text-sm text-neutral-300 max-w-sm leading-relaxed">
              "{AGENCY_INFO.tagline}"
            </p>

            <p className="text-xs text-neutral-400 max-w-sm leading-relaxed">
              Agência especializada em criação de sites profissionais, cardápios digitais e portais corporativos de alto padrão com entrega recorde em até 1h.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href={AGENCY_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#141414] border border-white/10 hover:border-[#D4AF37] text-neutral-300 hover:text-[#D4AF37] flex items-center justify-center transition-colors"
                aria-label="Instagram @velloxstudio.ofc"
                title="Siga a Vellox Studio no Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href={createWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#141414] border border-white/10 hover:border-[#D4AF37] text-neutral-300 hover:text-[#D4AF37] flex items-center justify-center transition-colors"
                aria-label="WhatsApp (11) 91022-2221"
                title="Fale no WhatsApp Oficial"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Navegação
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">Sobre a Agência</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Serviços</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">Portfólio de Projetos</a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">Depoimentos</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">Solicitar Orçamento</a>
              </li>
            </ul>
          </div>

          {/* Services Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Serviços
            </h4>
            <ul className="space-y-2 text-xs">
              {SERVICES_LIST.map((srv) => (
                <li key={srv.id}>
                  <a
                    href={createWhatsAppUrl(srv.whatsappMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors"
                  >
                    {srv.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Atendimento
            </h4>
            <div className="space-y-2 text-xs text-neutral-300">
              <p>
                <span className="text-neutral-500 block">WhatsApp Oficial:</span>
                <a
                  href={createWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-[#D4AF37] font-semibold"
                >
                  {AGENCY_INFO.phoneDisplay}
                </a>
              </p>
              <p>
                <span className="text-neutral-500 block">Instagram:</span>
                <a
                  href={AGENCY_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-[#D4AF37]"
                >
                  {AGENCY_INFO.instagramHandle}
                </a>
              </p>
              <p>
                <span className="text-neutral-500 block">Horário:</span>
                Segunda a Sábado, 08h às 21h
              </p>
            </div>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            <span>&copy; {new Date().getFullYear()} Vellox Studio. Todos os direitos reservados.</span>
          </div>

          <div className="flex items-center gap-6">
            <span>Sites Profissionais com Entrega Ágil</span>
            <button
              type="button"
              onClick={scrollToTop}
              className="inline-flex items-center gap-1.5 text-neutral-400 hover:text-[#D4AF37] transition-colors focus:outline-none"
              aria-label="Voltar ao topo da página"
            >
              <span>Voltar ao topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
