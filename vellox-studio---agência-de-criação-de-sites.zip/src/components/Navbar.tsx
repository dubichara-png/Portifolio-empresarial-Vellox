import React, { useState, useEffect } from 'react';
import { MessageSquare, Instagram, Menu, X, ArrowUpRight } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0A0A0A]/90 backdrop-blur-md border-b border-white/10 shadow-2xl shadow-black/80 py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          
          {/* Zone 1: Single element brand wordmark */}
          <a
            href="#inicio"
            className="flex items-center gap-2.5 text-xl sm:text-2xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
            aria-label="Vellox Studio - Início"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1F1F1F] to-[#121212] border border-[#D4AF37]/40 flex items-center justify-center transition-transform duration-300 group-hover:scale-105 group-hover:border-[#D4AF37]">
              <span className="text-[#D4AF37] font-extrabold text-base tracking-tighter">V</span>
            </div>
            <span>
              Vellox<span className="text-[#D4AF37] font-semibold">.</span>Studio
            </span>
          </a>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav
            className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-300"
            aria-label="Navegação principal"
          >
            <a
              href="#inicio"
              className="hover:text-white hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
            >
              Início
            </a>
            <a
              href="#sobre"
              className="hover:text-white hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
            >
              Sobre
            </a>
            <a
              href="#servicos"
              className="hover:text-white hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
            >
              Serviços
            </a>
            <a
              href="#portfolio"
              className="hover:text-white hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
            >
              Portfólio
            </a>
            <a
              href="#depoimentos"
              className="hover:text-white hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
            >
              Depoimentos
            </a>
            <a
              href="#contato"
              className="hover:text-white hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 focus-visible:ring-1 focus-visible:ring-[#D4AF37] outline-none"
            >
              Contato
            </a>
          </nav>

          {/* Zone 3: 1 primary action + Social Link */}
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <a
              href={AGENCY_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-neutral-400 hover:text-[#D4AF37] transition-colors rounded-lg hover:bg-white/5 focus-visible:ring-2 focus-visible:ring-[#D4AF37] outline-none"
              aria-label="Instagram da Vellox Studio @velloxstudio.ofc"
              title="Siga @velloxstudio.ofc no Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>

            <a
              href={createWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0A0A0A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#C59F2D] hover:opacity-95 active:scale-95 transition-all duration-200 rounded-lg shadow-md shadow-[#D4AF37]/20 whitespace-nowrap shrink-0 focus-visible:ring-2 focus-visible:ring-white outline-none"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-current" />
              <span>Solicitar Orçamento</span>
              <ArrowUpRight className="w-3.5 h-3.5 ml-0.5 opacity-70" />
            </a>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={createWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#D4AF37] hover:bg-white/5 rounded-lg text-xs font-medium"
              aria-label="WhatsApp da agência"
            >
              <MessageSquare className="w-5 h-5 fill-current" />
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-neutral-300 hover:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              aria-expanded={mobileMenuOpen}
              aria-label="Abrir menu de navegação"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F0F0F] border-b border-white/10 px-4 pt-4 pb-6 space-y-3">
          <nav className="flex flex-col space-y-2 text-base font-medium text-neutral-200">
            <a
              href="#inicio"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-white/5 hover:text-[#D4AF37]"
            >
              Início
            </a>
            <a
              href="#sobre"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-white/5 hover:text-[#D4AF37]"
            >
              Sobre a Vellox
            </a>
            <a
              href="#servicos"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-white/5 hover:text-[#D4AF37]"
            >
              Nossos Serviços
            </a>
            <a
              href="#portfolio"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-white/5 hover:text-[#D4AF37]"
            >
              Portfólio de Projetos
            </a>
            <a
              href="#depoimentos"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-white/5 hover:text-[#D4AF37]"
            >
              Depoimentos de Clientes
            </a>
            <a
              href="#contato"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-white/5 hover:text-[#D4AF37]"
            >
              Fazer Orçamento
            </a>
          </nav>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2.5">
            <a
              href={createWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 text-sm font-semibold text-[#0A0A0A] bg-[#D4AF37] rounded-lg"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>Falar no WhatsApp (11) 91022-2221</span>
            </a>
            <a
              href={AGENCY_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 text-xs text-neutral-400 hover:text-white"
            >
              <Instagram className="w-4 h-4 text-[#D4AF37]" />
              <span>Instagram: @velloxstudio.ofc</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
