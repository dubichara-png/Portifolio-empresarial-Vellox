import React from 'react';
import { MessageSquare, ArrowRight, ShieldCheck, Zap, Coins, CheckCircle2 } from 'lucide-react';
import { AGENCY_INFO, STATS } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const HeroSection: React.FC = () => {
  return (
    <section
      id="inicio"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-[#0A0A0A]"
    >
      {/* Background Subtle Radial Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] pointer-events-none opacity-40 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#D4AF37]/15 via-transparent to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Value Proposition & CTAs */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* Tagline kicker: clean unboxed text */}
            <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold tracking-wider uppercase text-[#D4AF37]">
              <span>Vellox Studio</span>
              <span aria-hidden="true" className="text-white/30">·</span>
              <span>Agência de Criação de Sites</span>
              <span aria-hidden="true" className="text-white/30">·</span>
              <span className="text-neutral-400 normal-case">Entrega em até 1h</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12] text-balance">
              Seu negócio merece estar no{' '}
              <span className="text-gold-gradient">
                próximo nível.
              </span>
            </h1>

            {/* Subtitle / Value proposition */}
            <p className="text-base sm:text-lg text-neutral-300 max-w-2xl leading-relaxed">
              Criamos sites modernos, profissionais e altamente estratégicos para empresas que 
              desejam superar a concorrência, transmitir autoridade imediata e converter visitantes 
              em clientes recorrentes.
            </p>

            {/* Key 3 Differentials highlight list */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-1">
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#141414] border border-white/5">
                <ShieldCheck className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Qualidade Profissional</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5 leading-snug">Design sob medida e código limpo</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#141414] border border-white/5">
                <Coins className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Sem Preços Absurdos</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5 leading-snug">Investimento justo e transparente</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#141414] border border-[#D4AF37]/30 shadow-sm shadow-[#D4AF37]/5">
                <Zap className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-[#F3E5AB] uppercase tracking-wider">Entrega em até 1h</h4>
                  <p className="text-[11px] text-neutral-300 mt-0.5 leading-snug">Metodologia acelerada e eficaz</p>
                </div>
              </div>
            </div>

            {/* CTAs Action Block */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <a
                href={createWhatsAppUrl('Olá Vellox Studio! Gostaria de solicitar um orçamento para o meu site e colocar meu negócio no próximo nível.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-7 py-4 text-sm sm:text-base font-bold text-[#0A0A0A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#C59F2D] hover:opacity-95 active:scale-[0.98] transition-all rounded-xl shadow-lg shadow-[#D4AF37]/20 whitespace-nowrap focus-visible:ring-2 focus-visible:ring-white outline-none"
              >
                <MessageSquare className="w-5 h-5 fill-current" />
                <span>Solicitar Orçamento no WhatsApp</span>
              </a>

              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm sm:text-base font-medium text-neutral-200 hover:text-white bg-[#141414] hover:bg-[#1A1A1A] border border-white/10 hover:border-white/20 transition-all rounded-xl whitespace-nowrap focus-visible:ring-2 focus-visible:ring-[#D4AF37] outline-none"
              >
                <span>Ver Portfólio</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
              </a>
            </div>

            {/* Micro reassurance badges */}
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-neutral-400 pt-1">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Sem mensalidades ocultas</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>100% adaptado para celular</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Atendimento direto pelo WhatsApp</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Frame */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Outer decorative gold subtle frame */}
              <div className="relative rounded-2xl overflow-hidden border border-[#D4AF37]/30 bg-[#121212] shadow-2xl shadow-black">
                <img
                  src="/src/assets/images/hero_vellox_studio_1794337246506.jpg"
                  alt="Estúdio de criação de sites Vellox Studio com telas de design responsivo de alto padrão"
                  className="w-full h-auto object-cover aspect-[4/3] sm:aspect-[16/10] lg:aspect-[4/3] filter brightness-95 contrast-105"
                  referrerPolicy="no-referrer"
                />

                {/* Subtle dark gradient overlay to ensure seamless integration */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent opacity-80" />

                {/* Floating Glass Detail Badge - Top Right */}
                <div className="absolute top-4 right-4 bg-[#0A0A0A]/85 backdrop-blur-md border border-[#D4AF37]/40 px-3.5 py-2 rounded-lg shadow-xl">
                  <div className="flex items-center gap-2">
                    <span className="text-[#D4AF37] font-bold text-xs">Vellox FastTrack</span>
                    <span className="text-[10px] text-neutral-300">· Entrega em 1h</span>
                  </div>
                </div>

                {/* Floating Glass Metric Card - Bottom Left */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#121212]/90 backdrop-blur-md border border-white/10 p-3.5 rounded-xl flex items-center justify-between gap-4">
                  <div>
                    <p className="text-[11px] font-medium text-neutral-400">Score de Performance & Mobile</p>
                    <p className="text-sm font-bold text-white">Carregamento Ultra Rápido (&lt; 0.8s)</p>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#F3E5AB] font-bold text-xs tabular-nums">
                    <span>99/100</span>
                  </div>
                </div>

              </div>

            </div>
          </div>

        </div>

        {/* Proof of impact statistics bar */}
        <div className="mt-16 pt-10 border-t border-white/10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            {STATS.map((stat, idx) => (
              <div key={idx} className="flex flex-col space-y-1">
                <span className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight tabular-nums">
                  <span className="text-[#D4AF37]">{stat.value}</span>
                </span>
                <span className="text-xs sm:text-sm font-semibold text-neutral-200">
                  {stat.label}
                </span>
                <span className="text-xs text-neutral-400 hidden sm:inline">
                  {stat.sublabel}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
