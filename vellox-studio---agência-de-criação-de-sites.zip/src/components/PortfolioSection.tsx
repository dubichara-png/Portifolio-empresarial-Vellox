import React, { useState } from 'react';
import { PORTFOLIO_LIST, PortfolioItem } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';
import { ExternalLink, X, MessageSquare, CheckCircle, ArrowRight, Layers } from 'lucide-react';

export const PortfolioSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeModalProject, setActiveModalProject] = useState<PortfolioItem | null>(null);

  const categories = [
    { id: 'all', label: 'Todos os Projetos' },
    { id: 'professional', label: 'Sites Profissionais' },
    { id: 'menu', label: 'Cardápios Digitais' },
    { id: 'institutional', label: 'Sites Institucionais' },
    { id: 'redesign', label: 'Redesign de Sites' },
  ];

  const filteredProjects = selectedCategory === 'all'
    ? PORTFOLIO_LIST
    : PORTFOLIO_LIST.filter((p) => p.category === selectedCategory);

  return (
    <section id="portfolio" className="py-20 md:py-28 bg-[#0D0D0D] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-10">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#D4AF37] mb-2.5">
            <span>Portfólio Selecionado</span>
            <span aria-hidden="true">·</span>
            <span>Cases Reais & Resultados</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white leading-tight">
            Projetos desenvolvidos para posicionar marcas e gerar oportunidades reais.
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 mt-3">
            Conheça alguns dos mais de 100 sites entregues pela Vellox Studio para empresas de destaque.
          </p>
        </div>

        {/* Category Filter Controls */}
        <div className="flex flex-wrap items-center gap-2 mb-12 border-b border-white/5 pb-4">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap focus-visible:ring-2 focus-visible:ring-[#D4AF37] outline-none ${
                selectedCategory === cat.id
                  ? 'bg-[#D4AF37] text-[#0A0A0A] font-bold shadow-md shadow-[#D4AF37]/20'
                  : 'bg-[#141414] text-neutral-300 hover:text-white hover:bg-[#1A1A1A] border border-white/5'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Projects Grid: 2 columns with rich cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group rounded-2xl overflow-hidden bg-[#121212] border border-white/10 hover:border-[#D4AF37]/50 transition-all duration-300 flex flex-col justify-between shadow-xl"
            >
              {/* Image Container with Zoom effect */}
              <div
                className="relative aspect-[4/3] overflow-hidden bg-[#181818] cursor-pointer"
                onClick={() => setActiveModalProject(project)}
              >
                <img
                  src={project.image}
                  alt={`Mockup do projeto ${project.title} desenvolvido por Vellox Studio`}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 filter brightness-95"
                  referrerPolicy="no-referrer"
                />
                
                {/* Floating category badge in top left */}
                <div className="absolute top-4 left-4 bg-[#0A0A0A]/85 backdrop-blur-md border border-white/10 px-3 py-1 rounded-md text-xs font-semibold text-white">
                  {project.categoryLabel}
                </div>

                {/* Speed tag top right */}
                <div className="absolute top-4 right-4 bg-[#D4AF37]/90 text-[#0A0A0A] font-bold text-[11px] px-2.5 py-1 rounded-md shadow-lg">
                  {project.deliverySpeed}
                </div>

                {/* Hover overlay hint */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                  <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0A0A0A]/90 text-xs font-semibold text-white border border-[#D4AF37]/40">
                    <ExternalLink className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Ver detalhes do projeto</span>
                  </span>
                </div>
              </div>

              {/* Card Meta Content */}
              <div className="p-6 sm:p-7 flex flex-col justify-between flex-grow">
                <div>
                  <div className="text-xs text-[#D4AF37] font-semibold mb-1">
                    {project.client}
                  </div>
                  <h3
                    onClick={() => setActiveModalProject(project)}
                    className="text-lg sm:text-xl font-bold text-white mb-2 cursor-pointer hover:text-[#F3E5AB] transition-colors"
                  >
                    {project.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-400 mb-4 line-clamp-2">
                    {project.description}
                  </p>

                  {/* Quantified impact metric */}
                  <div className="p-3 rounded-lg bg-[#181818] border border-white/5 mb-5 flex items-center gap-2 text-xs">
                    <CheckCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                    <span className="text-neutral-200 font-medium">Resultado: <strong className="text-white">{project.results}</strong></span>
                  </div>

                  {/* Clean unboxed tags */}
                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-neutral-400 mb-6">
                    {project.tags.map((tag, tIdx) => (
                      <span key={tIdx} className="bg-white/5 px-2 py-0.5 rounded text-neutral-300">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => setActiveModalProject(project)}
                    className="flex-1 py-2.5 px-3 rounded-lg text-xs font-semibold text-neutral-200 bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-center"
                  >
                    Ver Especificações
                  </button>

                  <a
                    href={createWhatsAppUrl(`Olá Vellox Studio! Gostei do projeto "${project.title}" e quero um site com esse mesmo nível de qualidade para minha empresa.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 px-3 rounded-lg text-xs font-bold text-[#0A0A0A] bg-[#D4AF37] hover:bg-[#C59F2D] transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <MessageSquare className="w-3.5 h-3.5 fill-current" />
                    <span>Quero um Igual</span>
                  </a>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Footnote reassurance */}
        <div className="mt-12 text-center text-xs text-neutral-400">
          <span>Tem uma referência ou layout em mente? </span>
          <a
            href={createWhatsAppUrl('Olá Vellox Studio! Tenho uma referência de site que gostaria de reproduzir com vocês.')}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#D4AF37] hover:underline font-semibold"
          >
            Envie sua ideia pelo WhatsApp e avaliamos a viabilidade agora.
          </a>
        </div>

      </div>

      {/* Project Detail Modal */}
      {activeModalProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-[#121212] border border-[#D4AF37]/40 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between p-5 border-b border-white/10 bg-[#161616]">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#D4AF37]" />
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  Detalhes do Projeto · Vellox Studio
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setActiveModalProject(null)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Fechar janela"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6">
              <div className="aspect-[16/10] rounded-xl overflow-hidden border border-white/10 bg-[#0A0A0A]">
                <img
                  src={activeModalProject.image}
                  alt={activeModalProject.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div>
                <span className="text-xs font-semibold text-[#D4AF37]">
                  {activeModalProject.categoryLabel} · {activeModalProject.client}
                </span>
                <h3 className="text-xl font-bold text-white mt-1">
                  {activeModalProject.title}
                </h3>
                <p className="text-sm text-neutral-300 mt-2 leading-relaxed">
                  {activeModalProject.description}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#181818] border border-white/5">
                  <div className="text-xs text-neutral-400 mb-1">Métrica de Impacto</div>
                  <div className="text-sm font-bold text-[#F3E5AB]">{activeModalProject.results}</div>
                </div>
                <div className="p-4 rounded-xl bg-[#181818] border border-white/5">
                  <div className="text-xs text-neutral-400 mb-1">Velocidade de Execução</div>
                  <div className="text-sm font-bold text-white">{activeModalProject.deliverySpeed}</div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0A0A0A] border border-white/10 space-y-2">
                <div className="text-xs font-semibold text-neutral-300">O que foi entregue:</div>
                <p className="text-xs text-neutral-400">
                  {activeModalProject.deliverable} com arquitetura focada em velocidade máxima, sem custos mensais de plataforma e link direto integrado ao WhatsApp.
                </p>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-5 border-t border-white/10 bg-[#161616] flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-neutral-400">
                Gostou deste padrão para sua empresa?
              </span>
              <a
                href={createWhatsAppUrl(`Olá! Vi o projeto "${activeModalProject.title}" no portfólio da Vellox Studio e quero um orçamento para um site similar.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-bold text-[#0A0A0A] bg-[#D4AF37] hover:bg-[#C59F2D] rounded-lg transition-colors whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4 fill-current" />
                <span>Pedir Projeto Semelhante no WhatsApp</span>
              </a>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
