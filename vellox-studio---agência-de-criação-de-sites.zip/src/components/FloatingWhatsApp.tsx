import React, { useState } from 'react';
import { MessageSquare, X, Send, Sparkles } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const FloatingWhatsApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userText, setUserText] = useState('');

  const handleSendCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const finalMsg = userText.trim()
      ? `Olá Vellox Studio! ${userText.trim()}`
      : AGENCY_INFO.defaultWhatsappText;
    window.open(createWhatsAppUrl(finalMsg), '_blank', 'noopener,noreferrer');
    setIsOpen(false);
    setUserText('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Pop-up Chat Card */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 bg-[#121212] border border-[#D4AF37]/40 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          
          {/* Card Header */}
          <div className="bg-[#181818] p-4 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-[#202020] border border-[#D4AF37]/60 flex items-center justify-center font-bold text-sm text-[#D4AF37]">
                  V
                </div>
                <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#181818]" title="Atendente online" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Vellox Studio</h4>
                <p className="text-[11px] text-[#D4AF37]">Online agora · Atendimento rápido</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Fechar janela de chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Card Body */}
          <div className="p-4 bg-[#0A0A0A] space-y-3">
            <div className="p-3 rounded-xl bg-[#181818] border border-white/5 text-xs text-neutral-200 leading-relaxed">
              Olá! 👋 Como podemos ajudar o seu negócio a alcançar o próximo nível hoje?
              <div className="mt-2 text-[10px] text-neutral-400">
                Criamos sites profissionais, cardápios digitais e redesigns com entrega em até 1h.
              </div>
            </div>

            {/* Quick action preset chips */}
            <div className="space-y-1.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  window.open(createWhatsAppUrl('Olá! Quero solicitar um orçamento para um Site Profissional.'), '_blank', 'noopener,noreferrer');
                  setIsOpen(false);
                }}
                className="w-full text-left p-2 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-neutral-300 hover:text-white transition-colors border border-white/5 flex items-center justify-between"
              >
                <span>Quero orçamento para Site Profissional</span>
                <span className="text-[#D4AF37]">&rarr;</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  window.open(createWhatsAppUrl('Olá! Gostaria de um orçamento para Cardápio Digital.'), '_blank', 'noopener,noreferrer');
                  setIsOpen(false);
                }}
                className="w-full text-left p-2 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-neutral-300 hover:text-white transition-colors border border-white/5 flex items-center justify-between"
              >
                <span>Preciso de um Cardápio Digital</span>
                <span className="text-[#D4AF37]">&rarr;</span>
              </button>
            </div>
          </div>

          {/* Card Footer Input Form */}
          <form onSubmit={handleSendCustom} className="p-3 bg-[#141414] border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              value={userText}
              onChange={(e) => setUserText(e.target.value)}
              placeholder="Digite sua dúvida..."
              className="flex-1 px-3 py-2 rounded-lg bg-[#1E1E1E] border border-white/10 text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-[#D4AF37]"
            />
            <button
              type="submit"
              className="p-2 rounded-lg bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#C59F2D] transition-colors"
              aria-label="Enviar mensagem no WhatsApp"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>
      )}

      {/* Floating Action Trigger Button */}
      <div className="flex items-center gap-2.5">
        {!isOpen && (
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#141414]/90 backdrop-blur-md border border-[#D4AF37]/30 text-[11px] font-medium text-white shadow-lg pointer-events-none">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Fale conosco no WhatsApp</span>
          </div>
        )}

        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Abrir atendimento no WhatsApp"
          aria-expanded={isOpen}
          className="relative group w-14 h-14 rounded-full bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#C59F2D] text-[#0A0A0A] flex items-center justify-center shadow-xl shadow-[#D4AF37]/30 hover:scale-105 active:scale-95 transition-all duration-200 focus-visible:ring-2 focus-visible:ring-white outline-none"
        >
          {isOpen ? (
            <X className="w-6 h-6 stroke-[2.5]" />
          ) : (
            <MessageSquare className="w-6 h-6 fill-current stroke-none" />
          )}

          {/* Attention indicator badge */}
          {!isOpen && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#0A0A0A] flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white" />
            </span>
          )}
        </button>
      </div>

    </div>
  );
};
