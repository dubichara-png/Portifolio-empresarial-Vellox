import React from 'react';
import { Check, MessageSquare, ArrowUpRight, Clock, Sparkles } from 'lucide-react';
import { SERVICES_LIST } from '../data/agencyData';
import { createWhatsAppUrl } from '../utils/whatsapp';

export const ServicesSection: React.FC = () => {
  return (
    <section id="servicos" className="py-20 md:py-28 bg-[#0A0A0A] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#D4AF37] mb-2.5">
              <span>Nossos Serviços</span>
              <span aria-hidden="true">·</span>
              <span>Soluções Sob Medida</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white leading-tight">
              Desenvolvimento de sites estratégicos de alto padrão.
            </h2>
          </div>
          <p className="text-sm sm:text-base text-neutral-400 max-w-md">
            Do cardápio digital interativo ao portal institucional completo: cada projeto é desenhado para gerar autoridade e vendas.
          </p>
        </div>

        {/* Services Bento Grid: 2 columns on desktop */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mt-12">
          {SERVICES_LIST.map((service, index) => {
            const indexNumber = `0${index + 1}`;
            const isFeatured = !!service.highlight;

            return (
              <div
                key={service.id}
                className={`relative flex flex-col justify-between p-7 sm:p-9 rounded-2xl transition-all duration-300 group ${
                  isFeatured
                    ? 'bg-[#121212] border border-[#D4AF37]/35 shadow-xl shadow-black/80 hover:border-[#D4AF37]'
                    : 'bg-[#111111] border border-white/10 hover:border-white/20 hover:bg-[#141414]'
                }`}
              >
                <div>
                  {/* Top line: clean number index and delivery indicator */}
                  <div className="flex items-center justify-between gap-4 mb-4">
                    <span className="text-xs font-mono font-bold text-[#D4AF37] tracking-wider">
                      {indexNumber}. SERVIÇO
                    </span>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-300">
                      <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>{service.deliveryTime}</span>
                    </div>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 group-hover:text-[#F3E5AB] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs font-medium text-[#D4AF37] mb-4">
                    {service.subtitle}
                  </p>

                  {/* Description */}
                  <p className="text-sm text-neutral-300 leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Feature Bullets */}
                  <div className="space-y-2.5 mb-8">
                    {service.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-300">
                        <Check className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Ideal For Note */}
                  <div className="text-xs text-neutral-400 border-t border-white/5 pt-4 mb-6">
                    <span className="font-semibold text-neutral-300">Ideal para: </span>
                    {service.idealFor}
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="pt-2">
                  <a
                    href={createWhatsAppUrl(service.whatsappMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center justify-center gap-2.5 w-full py-3.5 px-5 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200 whitespace-nowrap focus-visible:ring-2 focus-visible:ring-white outline-none ${
                      isFeatured
                        ? 'bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#C59F2D] text-[#0A0A0A] hover:opacity-95 shadow-md shadow-[#D4AF37]/20'
                        : 'bg-white/5 hover:bg-[#D4AF37] hover:text-[#0A0A0A] text-white border border-white/10 hover:border-[#D4AF37]'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4 fill-current" />
                    <span>Pedir este serviço no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 opacity-75" />
                  </a>
                </div>

              </div>
            );
          })}
        </div>

        {/* Global callout banner for custom requests */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-[#121212] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base sm:text-lg font-bold text-white">
                Precisa de uma estrutura personalizada para o seu negócio?
              </h4>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                Analisamos sua demanda pontual e enviamos uma proposta técnica sem compromisso em minutos.
              </p>
            </div>
          </div>

          <a
            href={createWhatsAppUrl('Olá Vellox Studio! Gostaria de consultar um projeto personalizado para minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/20 rounded-xl transition-all whitespace-nowrap shrink-0"
          >
            <span>Consultar Projeto Personalizado</span>
            <ArrowUpRight className="w-4 h-4 text-[#D4AF37]" />
          </a>
        </div>

      </div>
    </section>
  );
};
