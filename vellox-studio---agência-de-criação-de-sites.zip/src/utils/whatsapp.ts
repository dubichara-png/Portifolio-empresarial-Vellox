import { AGENCY_INFO } from '../data/agencyData';

export function createWhatsAppUrl(customMessage?: string): string {
  const message = customMessage || AGENCY_INFO.defaultWhatsappText;
  return `https://wa.me/${AGENCY_INFO.phoneRaw}?text=${encodeURIComponent(message)}`;
}

export function formatQuoteMessage(data: {
  name: string;
  phone: string;
  company?: string;
  service: string;
  urgency: string;
  details?: string;
}): string {
  let msg = `Olá Vellox Studio!\n\n`;
  msg += `Gostaria de solicitar um orçamento:\n`;
  msg += `• Nome: ${data.name}\n`;
  msg += `• Telefone/WhatsApp: ${data.phone}\n`;
  if (data.company) {
    msg += `• Empresa: ${data.company}\n`;
  }
  msg += `• Serviço desejado: ${data.service}\n`;
  msg += `• Prazo desejado: ${data.urgency}\n`;
  if (data.details) {
    msg += `• Detalhes: ${data.details}\n`;
  }
  msg += `\nAguardo o retorno para darmos o próximo passo!`;
  return msg;
}
