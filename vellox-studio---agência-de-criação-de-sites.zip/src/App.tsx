import React from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col selection:bg-[#D4AF37]/30 selection:text-[#F3E5AB]">
      {/* Top Bar Navigation */}
      <Navbar />

      {/* Main Content Sections (Strict Order as requested) */}
      <main className="flex-grow">
        {/* 1. Seção inicial impactante */}
        <HeroSection />

        {/* 2. Sobre / Quem sou */}
        <AboutSection />

        {/* 3. Serviços */}
        <ServicesSection />

        {/* 4. Portfólio / Projetos */}
        <PortfolioSection />

        {/* 5. Depoimentos */}
        <TestimonialsSection />

        {/* 6. Formulário de contato */}
        <ContactSection />
      </main>

      {/* 7. WhatsApp flutuante */}
      <FloatingWhatsApp />

      {/* Quiet Corporate Footer */}
      <Footer />
    </div>
  );
}
